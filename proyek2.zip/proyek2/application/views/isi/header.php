  
<div class="main-panel" style="height: 100vh;">
<nav class="navbar navbar-expand-dark navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          
            <a class="navbar-brand" href="javascript:;">E-Recruitment</a>
        </div>
      </nav>

  
