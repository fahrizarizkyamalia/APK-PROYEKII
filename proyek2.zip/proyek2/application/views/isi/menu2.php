  <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="<?php echo base_url();?>assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />>
  <link href="<?php echo base_url();?>assets/demo/demo.css" rel="stylesheet" />

<div class="wrapper ">
    <div class="sidebar" data-color="dark" data-active-color="success">
      <div class="logo">
        <a href="https://www.creative-tim.com" class="simple-text logo-mini">
        </a>
        <a href="<?= base_url('index.php/home1/Pageadmin'); ?>" class="simple-text logo-normal">
          Dashboard Admin
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active ">
            <a href="<?= base_url('index.php/biodata/pelamar'); ?>">
              <i class="nc-icon nc-bank"></i>
              <p>Data Pelamar</p>
            </a>
          </li>
          <li>
            <a href="<?= base_url('index.php/berkas'); ?>">
              <i class="nc-icon nc-diamond"></i>
              <p>Data Berkas</p>
            </a>
          </li>
          <li>
            <a href="<?= base_url('index.php/pengumuman'); ?>">
              <i class="nc-icon nc-pin-3"></i>
              <p>Data Pengumuman</p>
            </a>
          </li>
          <li>
            <a href="<?= base_url('index.php/hasil'); ?>">
              <i class="nc-icon nc-pin-3"></i>
              <p>Data hasil seleksi</p>
            </a>
          </li>
          <li>
            <a href="<?= base_url('index.php/syarat'); ?>">
              <i class="nc-icon nc-pin-3"></i>
              <p>Data syarat</p>
            </a>
          </li>
          <li>
            <a href="<?= base_url('index.php/lowongan'); ?>">
              <i class="nc-icon nc-pin-3"></i>
              <p>Lowongan</p>
            </a>
          </li>
          <li>
            <a href="<?= base_url('index.php/prosedur'); ?>">
              <i class="nc-icon nc-pin-3"></i>
              <p>Data Prosedur</p>
            </a>
          </li>
           <li>
            <a href="<?= base_url('index.php/user'); ?>">
              <i class="nc-icon nc-pin-3"></i>
              <p>Data User</p>
            </a>
          </li>
          <li>
           <a href="<?= base_url('index.php/tutor/logout'); ?>">
              <i class="nc-icon nc-pin-3"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel" style="height: 100vh;">
   <script src="<?php echo base_url();?>assets/js/core/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/core/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/core/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <script src="<?php echo base_url();?>assets/js/plugins/chartjs.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/plugins/bootstrap-notify.js"></script>
  <script src="<?php echo base_url();?>assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
