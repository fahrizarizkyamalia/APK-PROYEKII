 
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Data Berkas Calon Tutor</title>
</head>

<body>
   
    <?php $this->load->view("isi/menu2.php"); ?>
      <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav> 
   

    <div class="container">
	<h3>Data Berkas Calon Tutor</h3>
	<?= $this->session->flashdata('success'); ?>
	<a href="<?= base_url('index.php/home1/tambahberkas'); ?>" class="btn btn-dark mb-2">Tambah Data</a>
	<div class="table-responsive table-striped">
	<table class="table">
		<thead>
		<tr>
			<th scope="col">No</th>
			<th scope="col">Nama Lengkap</th>
			<th scope="col">CV</th>
			<th scope="col">KTP</th>
			<th scope="col">Aksi</th>
			
		</tr>
	</thead>

<?php
        $no = 1; 
		foreach($berkas as $row){
    ?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $row->nama_lengkap ?></td>
			<td><?php echo $row->cv?></td>
			<td><?php echo $row->ktp ?></td>

			<td><a href="<?php echo base_url() ?>index.php/Berkas/download/<?php echo $row->id_berkas?>" class="badge badge-danger" onclick="return confirm('Apakah kamu ingin Mendownload Berkas ini?');">Download KTP</a> </td>
			<td><a href="<?php echo base_url() ?>index.php/Berkas/download2/<?php echo $row->id_berkas?>" class="badge badge-success" onclick="return confirm('Apakah kamu ingin Mendownload Berkas ini?');">Download CV</a> </td>
		</tr>
	<?php } ?>
	<?php} else {?> 

		<tr>
			<td colspan="4" align="center"></td>
		</tr>
	<?php ?>
</table>
</center>
</div>
</div>
</body>
</html>