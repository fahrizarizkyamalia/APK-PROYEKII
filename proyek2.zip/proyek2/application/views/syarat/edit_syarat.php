<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Syarat Pendaftaran</title>
</head>

<body>
   
    <?php $this->load->view("isi/menu2.php"); ?>
    <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
	<h3>Syarat Pendaftaran</h3>
    <?php echo form_open('syarat/update') ?>
	<div class="table-responsive table-striped">
	<table class="table">
                     <div class="form-group">
                        <label for="text">Id Syarat</label>
                        <input type="text" name="id_syarat" value="<?php echo $data_syarat->id_syarat?>" class="form-control" placeholder="">
                        <input type="hidden" value="<?php echo $data_syarat->id_syarat ?>" name="id_syarat">
                      </div>
                    <div class = "form-group">
                        <label>Lowongan</label>
                        <select name="lowongan" class="form-control">
                            <?php foreach ($lowongan as $row): ?>
                                <option value="<?php echo $row->id_lowongan ?>" <?php if($row->id_lowongan == $data_syarat->id_syarat) echo 'selected'; ?>><?php echo $row->nama_lowongan ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <div class="form-group">
                <label for="text">syarat</label>
                <input type="text" name="isi_syarat" value="<?php echo $data_syarat ->isi_syarat?>" class="form-control" placeholder="">
                </div>
            <p><button type="submit" class="btn btn-dark mb-2" onclick= "return confirm ('Apakah kamu ingin mengubah data ini?')";>Update</button></p>
             <p> <button type="reset" class="btn btn-dark mb-2">reset</button></p>