<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Data User</title>
</head>

<body>

   <?php $this->load->view("isi/menu2.php"); ?>
    <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
	<h3>Data User</h3>
  <?php echo form_open('user/update') ?>
	<div class="table-responsive table-striped">
	<table class="table">
        <div class="form-group">
                 <div class="form-group">
                        <label for="text">Id User</label>
                        <input type="text" name="id_registrasi" value="<?php echo $data_user->id_registrasi?>" class="form-control" placeholder="">
                        <input type="hidden" value="<?php echo $data_user->id_registrasi ?>" name="id_registrasi">
                 </div>
                <label for="text">Username</label>
                <input type="text" name="usernmae" value="<?php echo $data_user ->username?>" class="form-control" placeholder="Masukkan username">
                <input type="hidden" value="<?php echo $data_user ->username?>" name="username">
              </div>

              <div class="form-group">
                <label for="text">password</label>
                <input type="text" name="password" value="<?php echo $data_user->password?>" class="form-control" placeholder="Masukkan password">
              </div>
               <div class="form-group">
                <label for="text">Nama Lengkap</label>
                <input type="text" name="nama_lengkap" value="<?php echo $data_user->nama_lengkap?>" class="form-control" >
              </div>
               <div class="form-group">
                <label for="text">Level</label>
                <input type="text" name="level" value="<?php echo $data_user->level?>" class="form-control" >
              </div>
               

            <p><button type="submit" class="btn btn-dark mb-2" onclick= "return confirm ('Apakah kamu ingin mengubah data ini?')";>Update</button></p>
             <p> <button type="reset" class="btn btn-dark mb-2">reset</button></p>