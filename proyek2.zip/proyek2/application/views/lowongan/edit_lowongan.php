<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Lowongan</title>
</head>

<body>
   <?php $this->load->view("isi/menu2.php"); ?>
    <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>
    <div class="container">
	<h3>Lowongan</h3>
    <?php echo form_open('lowongan/update') ?>
	<div class="table-responsive table-striped">
	<table class="table">
        <div class="form-group">
               <div class="form-group">
                <label for="text">Id Lowongan</label>
                <input type="text" name="id_lowongan" value="<?php echo $data_lowongan->id_lowongan?>" class="form-control" placeholder="">
                <input type="hidden" value="<?php echo $data_lowongan->id_lowongan ?>" name="id_lowongan">
              </div>
                <label for="text">Nama Lowongan</label>
                <input type="text" name="nama_lowongan" value="<?php echo $data_lowongan ->nama_lowongan?>" class="form-control" placeholder="">
              </div>

              <div class="form-group">
                <label for="text">Status</label>
                <input type="text" name="status" value="<?php echo $data_lowongan->status ?>" class="form-control" placeholder="">
              </div>
            <p><button type="submit" class="btn btn-dark mb-2" onclick= "return confirm ('Apakah kamu ingin mengubah data ini?')";>Update</button></p>
             <p> <button type="reset" class="btn btn-dark mb-2">reset</button></p>