<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Lowongan</title>
</head>

<body>
   
     <?php $this->load->view("isi/menu2.php"); ?>
      <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>
    

    <div class="container">
	<h3>Lowongan</h3>
	<a href="<?= base_url('index.php/lowongan/Tambah'); ?>" class="btn btn-dark mb-2">Tambah Data</a>
	<?php echo $this->session->flashdata('notif') ?>
	<div class="table-responsive table-striped">
	<table class="table">
		<thead>

		<tr>
			<th scope="col">No</th>
			<th scope="col">Nama Lowongan</th>
			<th scope="col">Status</th>
			<th scope="col">AKSI  </th>
		</tr>
	</thead>
	<tbody>
	<?php
        $no = 1; 
		foreach($data_lowongan as $row){ 
    ?>

		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $row->nama_lowongan?></td>
			<td><?php echo $row->status?></td>

			<td><a href="<?php echo base_url() ?>index.php/lowongan/hapus/<?php echo $row->id_lowongan?>" class="badge badge-danger" onclick="return confirm('Apakah kamu ingin menghapus data ini?');">Hapus</a> </td>
            <td><a href="<?php echo base_url() ?>index.php/lowongan/edit/<?php echo $row->id_lowongan?>" class="badge badge-warning">Ubah</a></td>

		</tr>
	<?php } ?>
	</tbody>
	</table>
</div>
    </div>
    </div>
    </div>