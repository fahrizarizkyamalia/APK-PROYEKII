<!doctype html>
<html lang="en">

<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Lowongan</title>
</head>

<body>
    <?php $this->load->view("isi/menu2.php"); ?>
    <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
        <div class="row mt-4">
            <div class="col-md-6">
                <h3>Info Lowongan</h3>
                <div class="card">
                    <div class="card-header">
                        
                    </div>
                    <div class="card-body">
                        <form action="simpan" method="post"> 
                            <div class="form-group">
                                <label for="text">Nama Lowongan</label>
                                <input type="text" class="form-control" id="nama_lowongan" name=nama_lowongan>
                            </div>

                            <div class="form-group">
                                <label for="text">Status</label>
                                <input type="nama" class="form-control" id="status" name="status">
                            </div>
                            <button type="submit" class="btn btn-dark float-right" name="tambah">Kirim</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <script src="<?= base_url('assets') ?>/js/bootstrap.min.js"></script>
</body>

</html>