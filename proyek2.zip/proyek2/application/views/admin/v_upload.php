<!doctype html>
<html lang="en">



<head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Upload Berkas</title>
</head>
 
<body>
    <?php $this->load->view("isi/menu2.php"); ?>
     <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>
  
  
    <div class="container" >
        <div class="content">
        <div class="row mt-4">
            <div class="col-md-6">
                <h3>Upload Berkas</h3>
                <div class="card">
                    <div class="card-header">
                        Berkas
                    </div>
                    <div class="card-body">
                        <?php echo form_open_multipart('berkas/create');?>
                        <?php echo $this->session->flashdata('notif') ?>
                            <div class="form-group">
                                <label for="text">Nama Lengkap</label>
                                <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" rows="3" >
                               
                            </div>
                            
                            
                                <label for="text">CV</label>
                                <input type="file" class="form-control" id="cv" name="cv" rows="3" >
                               
                            
                        
                                <label for="file">KTP</label>
                                <input type="file" class="form-control" id="ktp" name="ktp">
                           
                            <input type="submit" class="btn btn-success" value="Simpan">
                             </form>
                    </div> 
                </div>
            </div>
        </div>
    </div>

   
    <script src="<?= base_url('assets') ?>/js/bootstrap.min.js"></script>
    
</body>

</html>