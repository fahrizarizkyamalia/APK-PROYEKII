<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Data Calon Tutor</title>
</head>

<body>
  <?php $this->load->view("isi/menu2.php"); ?>
   
    <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
	<h3>Data Calon Tutor</h3>
	   <?php echo form_open('biodata/update') ?>
	<div class="table-responsive table-striped">
	<table class="table">
              <div class="form-group">
                        <label for="text">Id Calon</label>
                        <input type="text" name="id_calon" value="<?php echo $data_calon->id_calon?>" class="form-control" placeholder="">
                        <input type="hidden" value="<?php echo $data_calon->id_calon?>" name="id_calon">
                </div>
               <div class="form-group">
                <label for="text">Nik</label>
                <input type="text" name="NIK" value="<?php echo $data_calon ->NIK?>" class="form-control" placeholder="Masukkan NIK">
                <input type="hidden" value="<?php echo $data_calon ->NIK ?>" name="NIK">
              </div>

              <div class="form-group">
                <label for="text">Nama Lengkap</label>
                <input type="text" name="nama_lengkap" value="<?php echo $data_calon->nama_lengkap ?>" class="form-control" placeholder="Masukkan Nama Lengkap">
              </div>
               <div class="form-group">
                <label for="text">Nama Panggilan</label>
                <input type="text" name="nama_panggilann" value="<?php echo $data_calon->nama_panggilann?>" class="form-control" >
              </div>
               </div>
               <div class="form-group">
                <label for="text">Jenis Kelamin</label>
                <input type="text" name="jenis_kelamin" value="<?php echo $data_calon->jenis_kelamin?>" class="form-control" >
              </div>
               </div>
               <div class="form-group">
                <label for="text">Agama</label>
                <input type="text" name="agama" value="<?php echo $data_calon->agama?>" class="form-control" >
              </div>
               </div>
               <div class="form-group">
                <label for="text">No HP</label>
                <input type="text" name="no_hp" value="<?php echo $data_calon->no_hp?>" class="form-control" >
              </div>
               </div>
               <div class="form-group">
                <label for="text">Pendidikan Terakhir</label>
                <input type="text" name="pend_terakhir" value="<?php echo $data_calon->pend_terakhir?>" class="form-control" >
              </div>

            <p><button type="submit" class="btn btn-dark mb-2">Update</button></p>
             <p> <button type="reset" class="btn btn-dark mb-2">reset</button></p>