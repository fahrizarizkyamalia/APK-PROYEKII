<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Prosedur Pendaftaran</title>
</head>

<body>
   
  <?php $this->load->view("isi/menu2.php"); ?>
    <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
	<h3>Prosedur Pendaftaran</h3>
	<?php echo form_open('prosedur/update') ?>
	<div class="table-responsive table-striped">
	<table class="table">
              <div class="form-group">
                <label for="text">Id Prosedur</label>
                <input type="text" name="id_prosedur" value="<?php echo $data_prosedur->id_prosedur?>" class="form-control" placeholder="Masukkan id Prosedur">
                <input type="hidden" value="<?php echo $data_prosedur->id_prosedur?>" name="id_prosedur">
              </div>
              <div class="form-group">
                <label for="text">Prosedur</label>
                <input type="text" name="isi_prosedur" value="<?php echo $data_prosedur->isi_prosedur?>" class="form-control" >
              </div>
            <p><button type="submit" class="btn btn-dark mb-2" onclick= "return confirm ('Apakah kamu ingin mengubah data ini?')";>Update</button></p>
             <p> <button type="reset" class="btn btn-dark mb-2">reset</button></p>