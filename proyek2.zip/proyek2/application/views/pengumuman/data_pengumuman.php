<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>PENGUMUMAN</title>
</head>

<body>
   
   <?php $this->load->view("isi/menu2.php"); ?>
    <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>
    <div class="container">
	<h3>PENGUMUMAN</h3>
		<a href="<?= base_url('index.php/pengumuman/Tambah'); ?>" class="btn btn-dark mb-2">Tambah Pengumuman</a>
		<?php echo $this->session->flashdata('notif') ?>
		<div class="jumbotron">
	<tbody>
	<?php 
      foreach($data_pengumuman as $data_pengumuman){ 
        ?>
		<tr>
			<td><?php echo $data_pengumuman->isi_pengumuman?></td>

		</tr>

	 <?php } ?>
	</tbody>
			<br>   	
				<a href="<?php echo site_url('pengumuman/edit/'.$data_pengumuman->id_pengumuman);?>" class="btn btn-dark mb-2">Edit Pengumuman</a>
				<a href="<?php echo site_url('pengumuman/hapus/'.$data_pengumuman->id_pengumuman);?>" class="btn btn-dark mb-2">Hapus Pengumuman</a>
			</br>
	</table>
</div>
</div>
</body>
</html>