<!DOCTYPE html>
<html>
<head>
    <title>Pengumuman</title>
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css');?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/vendors/bootstrap-wysihtml5/src/bootstrap-wysihtml5.css');?>">
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet" media="screen">
    <link href="<?php echo base_url('assets/styles.css');?>" rel="stylesheet" media="screen">
</head>
<body>
 <?php $this->load->view("isi/menu2.php"); ?>
    <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>
  <div class="container" style="margin-top: 80px">
  	
        <div class="col-md-12" >
            <?php echo form_open('pengumuman/simpan'); ?>

	  <div class="form-group">
                <label for="texarea">Isi Pengumuman</label>
                <input type="textarea" name="isi_pengumuman" class="form-control" style="width:98%;height:200px;"> 
              </div>
		<button type="submit" class="btn btn-md btn-success mb-2">Submit</button>
		</div>
  </div>
</div>
</body>
	</div>
</div>