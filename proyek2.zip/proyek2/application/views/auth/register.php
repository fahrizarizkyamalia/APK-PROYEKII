<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Registrasi</title>
    <link href="<?php echo base_url('assets/css/bootstrap.min.css');?>" rel="stylesheet">
  </head>
  <body>
      <center>
      <div class="container">
       <div class="col-md-4 col-md-offset-4">
         <form class="form-signin" action="<?php echo site_url('tutor/registerform');?>" method="post">
           <h2 class="form-signin-heading"></h2>
           <h2 class="form-signin-heading">Register</h2>
           <div class="card">
           <?php echo $this->session->flashdata('msg');?>
           <label for="username" class="sr-only">Username</label>
           <input type="text" name="username" class="form-control" placeholder="Username" required autofocus>
           <label for="password" class="sr-only">Password</label>
           <input type="password" name="password" class="form-control" placeholder="Password" required>
           <label for="text" class="sr-only">Nama Lengkap</label>
           <input type="text" name="nama_lengkap" class="form-control" placeholder="Nama Lengkap" required>
           <div class="form-group form-group-sm row">
              <div class="col-sm-6">
                <select name="level" class="form-control" required>
                  <option value="">-Pilih Level-</option>
                  <option value="admin">admin</option>
                  <option value="calon">calon</option>
                </select>
              </div>
            </div>
           
           <button class="btn btn-lg btn-primary btn-block" type="submit">Daftar</button>
           <a href="<?= base_url('index.php/tutor') ?>"class="float-left mt-3">sudah Punya akun ? Login  </a>
         </form>
       </div>
       </div> <!-- /container -->
     </center>

    <script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script>
  </body>
</html>
