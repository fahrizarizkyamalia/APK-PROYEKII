<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Hasil Seleksi </title>
</head>

<body>
   
    
    <?php $this->load->view("isi/menu.php"); ?>
     <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
	<h3>Hasil Seleksi</h3>
	<div class="table-responsive table-striped">
	<table class="table">
		<thead>

		<tr>
			<th scope="col">No</th>
			<th scope="col">Nama Lengkap</th>
			<th scope="col">Hasil</th>
		</tr>
	</thead>
	<tbody>
	<?php
        $no = 1; 
		foreach($data_hasil as $row){ 
    ?>

		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $row->nama_lengkap ?></td>
			<td><?php echo $row->hasil?></td>


		</tr>
	<?php } ?>
	</tbody>
	</table>
</div>
    </div>
    </div>
    </div>