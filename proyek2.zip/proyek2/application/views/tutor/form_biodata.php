<!doctype html>
<html lang="en">

<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Data Diri</title>
</head>

<body>
    <?php $this->load->view("isi/menu.php"); ?>
  
     <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
        <div class="row mt-7">
            <div class="col-md-9">
                <h3>Data Diri calon Tutor</h3>
                <div class="card">
                    <div class="card-header">
                        
                    </div>
                    <div class="card-body">
                        <form action="simpan" method="post"> 
                            <?php echo $this->session->flashdata('notif') ?>
                            <div class="form-group">
                                <label for="text">NIK</label>
                                <input type="nama" class="form-control" id="NIK" name="NIK">
                            </div>

                            <div class="form-group">
                                <label for="text">Nama Lengkap</label>
                                <input type="nama" class="form-control" id="nama_lengkap" name="nama_lengkap">
                            </div>
                            <div class="form-group">
                                <label for="file">Nama Panggilan</label>
                                <input type="text" class="form-control" id="nama_panggilann" name="nama_panggilann">
                               
                            </div>
                            <div class="form-group">
                                <label for="file">Jenis kelamin</label>
                                <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                            </div>
                            <div class="form-group">
                                <label for="file">Tempat Lahir</label>
                                <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir">
                            </div>
                            <div class="form-group">
                                <label for="file">Tanggal Lahir</label>
                                <input type="Date" class="form-control" id="tgl_lahir" name="tgl_lahir">
                            </div>
                            <div class="form-group">
                                <label for="file">Agama</label>
                                <input type="text" class="form-control" id="agama" name="agama">
                            </div>
                            <div class="form-group">
                                <label for="file">Alamat</label>
                                <input type="text" class="form-control" id="alamat" name="alamat">
                            </div>
                            <div class="form-group">
                                <label for="file">Kode Pos</label>
                                <input type="text" class="form-control" id="kode_pos" name="kode_pos">
                            </div>
                            <div class="form-group">
                                <label for="file">Bahasa yang dikuasai</label>
                                <input type="text" class="form-control" id="bhs_sehari" name="bhs_sehari">
                            </div>
                            <div class="form-group">
                                <label for="file">Golongan Darah</label>
                                <input type="text" class="form-control" id="golongan_darah" name="golongan_darah">
                            </div>
                            <div class="form-group">
                                <label for="file">Pendidikan Terakhir</label>
                                <input type="text" class="form-control" id="pend_terakhir" name="pend_terakhir">
                            </div>
                            <div class="form-group">
                                <label for="text">NO HP</label>
                                <input type="text" class="form-control" id="no_hp" name="no_hp">
                            </div>
                            <div class="form-group">
                                <label>Lowongan</label>
                                <select name="lowongan" class="form-control">
                                    <?php 

                                    foreach ($lowongan as $row) {?>
                                        <option value="<?php echo $row->id_lowongan?>"><?php echo $row->nama_lowongan?></option>
                                    <?php }?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-dark float-right" name="tambah">Kirim</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <script src="<?= base_url('assets') ?>/js/bootstrap.min.js"></script>
</body>
</html>