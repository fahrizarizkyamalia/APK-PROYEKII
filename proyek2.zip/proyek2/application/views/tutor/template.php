<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	
	<title>E-RECRUITMENT</title>
	
	<link href="<?php echo base_url('assets/bootstrap/css/bootstrap.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/bootstrap/css/custom2.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/datatables/css/jquery.dataTables.min.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/datatables/css/dataTables.bootstrap.min.css');?>" rel="stylesheet">
<body>
	 <nav class="navbar navbar-dark bg-dark">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
        <div class="row">
    </nav>
		<div class="jumbotron">
			<center>
		  <h1>Selamat Datang!</h1>
		  <p>Selamat Datang di Website E-recruitment Tutor Bimbingan Belajar Sebelum melakukan pendaftaran,
		  <p>sebaiknya anda membaca syarat-syarat pendaftaran terlebih dahulu dihalaman <b><?php echo anchor('tutor/syarat','Syarat Pendaftaran');?></p></p></b>
		  <p>sebaiknya anda memahami prosedur pendaftaran terlebih dahulu dihalaman <b><?php echo anchor('tutor/prosedur','Prosedur Pendaftaran');?></p></p></b>
		  <p>sebaiknya anda melihat info lowongan yang tersedia terlebih dahulu dihalaman <b><?php echo anchor('tutor/lowongan','info Lowongan');?></p></p></b>
		  <p> Untuk mengetahui informasi terbaru mengenai <b>E-recruitment</b> anda dapat melihatnya
		  pada halaman <b><?php echo anchor('tutor/pengumuman2','Pengumuman');?></b></p>
		  
		  <p>Jika anda sudah memahami prosedur pendaftaran, silahkan klik tombol <b>Daftar</b> dibawah ini untuk melakukan <b>Pendaftaran!</b></p>
		  <P> jika anda admin silahkan langsung klik tombol <b>login</b> dibawah ini
		 <p><a class="btn btn-warning btn-lg" href="<?php echo site_url('tutor/register');?>" role="button">Daftar</a>
		  <a class="btn btn-warning btn-lg" href="<?php echo site_url('tutor');?>" role="button">Login</a></p>
		</div>
		</center>
	</div>
<script type="text/javascript" src="<?php echo base_url('assets/bootstrap/js/jquery.min.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/datatables/js/jquery.dataTables.min.js');?>"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$('.data').DataTable();
	});
</script>
</body>
</html>