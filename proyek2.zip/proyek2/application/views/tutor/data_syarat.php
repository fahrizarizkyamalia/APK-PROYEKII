<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>syarat Pendaftaran</title>
</head>

<body>
   
    <nav class="navbar navbar-dark bg-dark">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
	<h3>syarat Pendaftaran</h3>
	<div class="table-responsive table-striped">
	<table class="table">
		<thead>

		<tr>
			<th scope="col">Lowongan</th>
			<th scope="col">syarat Pendaftaran</th>
		</tr>
	</thead> 
	<tbody>
	<?php
     
		foreach($data_syarat as $row){ 
    ?>

		<tr>
			<td><?php echo $row->nama_lowongan?></td>
			<td><?php echo $row->isi_syarat?></td>

		</tr>
	<?php } ?>
	</tbody>
	</table>
</div>
    </div>
    </div>
    </div>