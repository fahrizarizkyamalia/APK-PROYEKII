<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>PENGUMUMAN</title>
</head>

<body>
    <?php $this->load->view("isi/menu.php"); ?>
     <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
	<h3>PENGUMUMAN</h3>
		<div class="jumbotron">
	<tbody>
	<?php 
      foreach($data_pengumuman as $data_pengumuman){ 
        ?>
		<tr>
			<td><?php echo $data_pengumuman->isi_pengumuman?></td>

		</tr>

	 <?php } ?>
	</tbody>
	</table>
</div>
</div>
<?php $this->load->view("isi/footer.php"); ?>
</body>
</html>