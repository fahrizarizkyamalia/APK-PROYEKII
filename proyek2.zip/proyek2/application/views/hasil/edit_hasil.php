<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="<?= base_url('assets'); ?>/css/bootstrap.min.css">

    <title>Data Hasil Seleksi</title>
</head>

<body>
   
   <?php $this->load->view("isi/menu2.php"); ?>
    <nav class="navbar navbar-dark bg-light">
        <div class="container">
            <span class="navbar-brand mb-0 h1"></span>
        </div>
    </nav>

    <div class="container">
	<h3>Data Hasil seleksi</h3>
	<?php echo form_open('hasil/update') ?>
	<div class="table-responsive table-striped">
	<table class="table">
              <div class="form-group">
                        <label for="text">Id Hasil</label>
                        <input type="text" name="id_hasil" value="<?php echo $data_hasil->id_hasil?>" class="form-control" placeholder="">
                        <input type="hidden" value="<?php echo $data_hasil->id_hasil?>" name="id_hasil">
                      </div>
              <div class = "form-group">
               <label>Lowongan</label>
               <select name="nama_lengkap" class="form-control">
                <?php foreach ($calon as $row): ?>
                  <option value="<?php echo $row->id_calon ?>" <?php if($row->id_calon == $data_hasil->id_hasil) echo 'selected'; ?>><?php echo $row->nama_lengkap ?></option>
                <?php endforeach; ?>
                </select>
                </div>
               <div class="form-group">
                <label for="text">Hasil</label>
                <input type="text" name="hasil" value="<?php echo $data_hasil->hasil?>" class="form-control" >
              </div>

            <p><button type="submit" class="btn btn-dark mb-2" onclick= "return confirm ('Apakah kamu ingin mengubah data ini?')";>Update</button></p>
             <p> <button type="reset" class="btn btn-dark mb-2">reset</button></p>