<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class m_pengumuman extends CI_Model {
	
 public function get_all()
    {
        $query = $this->db->select("*")
                 ->from('pengumuman')
                 ->order_by('id_pengumuman', 'DESC')
                 ->get();
        return $query->result();
    }

    public function simpan($data)
    {

        $query = $this->db->insert("pengumuman", $data);

        if($query){
            return true;
        }else{
            return false;
        }

    }

     public function edit($id_pengumuman)
    {

        $query = $this->db->where("id_pengumuman", $id_pengumuman)
                ->get("pengumuman");

        if($query){
            return $query->row();
        }else{
            return false;
        }

    }

    public function update($data, $id)
    {

        $query = $this->db->update("pengumuman", $data, $id);

        if($query){
            return true;
        }else{
            return false;
        }

    }

    public function hapus($id_pengumuman)
    {

        $query = $this->db->delete("pengumuman", $id_pengumuman);

        if($query){
            return true;
        }else{
            return false;
        }

    }

}