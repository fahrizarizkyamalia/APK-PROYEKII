  <?php
 
class berkas_model extends CI_Model
{

	public function getTable()
	{
		$this->db->select("*");
		$this->db->from('berkas');
		$query = $this->db->get();
		return $query->result();
	}
	public function view(){

		return $this->db->get('berkas')->result();
	}


	public function simpan($data)
    {

        $query = $this->db->insert("berkas", $data);

        if($query){
            return true;
        }else{
            return false;
        }

    }
}