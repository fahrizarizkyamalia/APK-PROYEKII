<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class m_hasil extends CI_Model {
	
 public function get_all()
    {
        $this->db->select('hasil_seleksi.*, calon.nama_lengkap');
                 $this->db->from('hasil_seleksi');
                $this->db->join('calon', ' calon.id_calon = hasil_Seleksi.id_calon');
                 $query = $this->db->get();
        return $query->result();
    }

    public function simpan($data)
    {

        $query = $this->db->insert("hasil_seleksi", $data);

        if($query){
            return true;
        }else{
            return false;
        }

    }


    public function get($id) {
        
        return $this->db->where('id_hasil', $id)->get('hasil_seleksi')->row();
    }

     public function edit($id_hasil)
    {

        $query = $this->db->where("id_hasil", $id_hasil)
                ->get("hasil_seleksi");

        if($query){
            return $query->row();
        }else{
            return false;
        }

    }

  public function Update($data, $id)
    {
        return $this->db->where('id_hasil', $id)->update('hasil_seleksi', $data);
    }

    public function hapus($id_hasil)
    {

        $query = $this->db->delete("hasil_seleksi", $id_hasil);

        if($query){
            return true;
        }else{
            return false;
        }

    }

}