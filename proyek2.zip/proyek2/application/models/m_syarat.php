<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class m_syarat extends CI_Model {
	
  public function get_all()
    {
                $this->db->select('syarat.*, lowongan.nama_lowongan');
                 $this->db->from('syarat');
                $this->db->join('lowongan', 'lowongan.id_lowongan = syarat.id_lowongan');
                 $query = $this->db->get();
        return $query->result();
    }
    public function simpan($data)
    {

        $query = $this->db->insert("syarat", $data);

        if($query){
            return true;
        }else{
            return false;
        }

    }


    public function get($id) {
        
        return $this->db->where('id_syarat', $id)->get('syarat')->row();
    }

     public function edit($id_syarat)
    {

        $query = $this->db->where("id_syarat", $id_syarat)
                ->get("syarat");

        if($query){
            return $query->row();
        }else{
            return false;
        }

    }

   public function Update($data, $id)
    {
        return $this->db->where('id_syarat', $id)->update('syarat', $data);
    }
    public function hapus($id_syarat)
    {

        $query = $this->db->delete("syarat", $id_syarat);

        if($query){
            return true;
        }else{
            return false;
        }

    }

}