<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class calon_model  extends CI_Model {
	
 public function get_all()
    {
                $this->db->select('calon.*, lowongan.nama_lowongan');
                 $this->db->from('calon');
                $this->db->join('lowongan', 'lowongan.id_lowongan = calon.id_lowongan');
                 $query = $this->db->get();
        return $query->result();
    }
    public function getAll()
    {
        return $this->db->get('calon')->result();

    }
    public function simpan($data)
    {

        $query = $this->db->insert("calon", $data);

        if($query){
            return true;
        }else{
            return false;
        }

    }

    public function get($id) {
        return $this->db->where('id_calon', $id)->get('calon')->row();
    }

     public function edit($id_calon)
    {

        $query = $this->db->where("id_calon", $id_calon)
                ->get("calon");

        if($query){
            return $query->row();
        }else{
            return false;
        }

    }

    public function update($data, $id)
    {

        $query = $this->db->update("calon", $data, $id);

        if($query){
            return true;
        }else{
            return false;
        }

    }

    public function hapus($id_calon)
    {

        $query = $this->db->delete("calon", $id_calon);

        if($query){
            return true;
        }else{
            return false;
        }

    }

}