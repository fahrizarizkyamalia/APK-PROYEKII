<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class user_model  extends CI_Model {
	
 public function get_all()
    {
        $query = $this->db->select("*")
                 ->from('registrasi')
                 ->order_by('id_registrasi', 'DESC')
                 ->get();
        return $query->result();
    }

    public function simpan($data)
    {

        $query = $this->db->insert("registrasi", $data);

        if($query){
            return true;
        }else{
            return false;
        }

    }

     public function edit($id_registrasi)
    {

        $query = $this->db->where("id_registrasi", $id_registrasi)
                ->get("registrasi");

        if($query){
            return $query->row();
        }else{
            return false;
        }

    }

    public function update($data, $id)
    {

        $query = $this->db->update("registrasi", $data, $id);

        if($query){
            return true;
        }else{
            return false;
        }

    }

    public function hapus($id_registrasi)
    {

        $query = $this->db->delete("registrasi", $id_calon);

        if($query){
            return true;
        }else{
            return false;
        }

    }

}