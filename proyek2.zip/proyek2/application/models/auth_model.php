<?php
 
class auth_model extends CI_Model
{
 
    public function cek_login($email)
    {
 
        $hasil = $this->db->where('username', $username)->limit(1)->get('registrasi');
        if($hasil->num_rows() > 0){
            return $hasil->row();
        } else {
            return array();
        }
    }

    function validate($username,$password){
    $this->db->where('username',$username);
    $this->db->where('password',$password);
    $result = $this->db->get('registrasi',1);
    return $result;
  }
 
    public function register($table, $data)
    {
        return $this->db->insert($table, $data);
    }
}
?>