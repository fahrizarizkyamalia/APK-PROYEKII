  <?php
 
class Berkas extends CI_Controller
 
{
  public function __construct(){
     parent::__construct();
     $this->load->model("berkas_model");
  }


  public function index()
  {
    $data['title'] = "upload berkas";
    $data['berkas'] = $this->berkas_model->view();
    $this->load->view('berkas/data_berkas', $data, FALSE);
  }

  public function data_berkas(){

   
    
    $this->load->view('berkas/v_upload');
     
  }

 public function create()
 {

        
        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required');

        $config['upload_path']          = './gambar/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 2048;
        $config['encrypt_name']         = TRUE;
        $this->load->library('upload', $config);

        if(!empty($_FILES['cv'])){
          $this->upload->do_upload('cv');
          $data1 = $this->upload->data();
          $cv = $data1['file_name']; 
        }

         if(!empty($_FILES['ktp'])){
          $this->upload->do_upload('ktp');
          $data2 = $this->upload->data();
          $ktp = $data2['file_name']; 
        }

        if ($this->form_validation->run())
        {
          $nama_lengkap= $this->input->post('nama_lengkap', TRUE);
          $data = ['nama_lengkap'=>$nama_lengkap , 'cv'=>$cv, 'ktp'=>$ktp];
          $insert = $this->berkas_model->simpan  ($data);
          if ($insert){
        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }else{
        $this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }
        }
      redirect('Berkas/data_berkas');
  }

    public function hapus($id_calon)
    {
        $id['id_calon'] = $this->uri->segment(3);

        $this->calon_model->hapus($id);

        //redirect
        redirect('biodata/');

    }

    public function download($id)
    {
      $data = $this->db->get_where('berkas',['id_berkas'=>$id])->row();
      force_download('gambar/'.$data->ktp,NULL);
    }

     public function download2($id)
    {
      $data = $this->db->get_where('berkas',['id_berkas'=>$id])->row();
      force_download('gambar/'.$data->cv,NULL);
    }


}
