<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class syarat extends CI_Controller {

    public function __construct(){

        parent ::__construct();

        $this->load->model('m_syarat'); 
        

    }

   public function index()
    {
       

           $data ["data_syarat"] = $this->m_syarat->get_all();
            $this->load->view('syarat/data_syarat', $data);
    }

    public function tambah(){

        $this->load->model('m_lowongan');
        $data['lowongan'] = $this->m_lowongan->get_all();
        $this->load->view('syarat/syarat', $data);
    }
  
   public function simpan(){

            $lowongan             =  $this->input->post("lowongan");
            $isi_syarat     =  $this->input->post("isi_syarat");
           


            $data = array(
                'id_lowongan'             => $lowongan,
                'isi_syarat'    => $isi_syarat,
            );

        

        $simpan = $this->m_syarat->simpan($data, 'syarat');

       if ($simpan){

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }else{
        $this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }
        redirect('syarat');
    }


     public function edit($id)
        {
            $this->load->model('m_lowongan');
            $this->load->model('m_syarat');

            $data['lowongan'] = $this->m_lowongan->get_all();

            $data['data_syarat'] = $this->m_syarat->get($id);

            $this->load->view('syarat/edit_syarat', $data);
        }


     public function update(){
            $this->load->model('m_syarat');
          
            $id = $this->input->post('id_syarat');
            $id_lowongan = $this->input->post('lowongan');
            $isi_syarat = $this->input->post('isi_syarat');

            $data = [
                'id_lowongan' => $id_lowongan,
                'isi_syarat' => $isi_syarat,
            
            ];

        $save = $this->m_syarat->update($data, $id);

        if($save) {
            $this->session->set_flashdata('msg_success', 'Data telah diubah!');
        } else {
            $this->session->set_flashdata('msg_error', 'Data gagal disimpan, silakan isi ulang!');
        }
        redirect('syarat');
    }


    
    public function hapus($id_syarat)
    {
        $id['id_syarat'] = $this->uri->segment(3);

        $this->m_syarat->hapus($id);

        
        redirect('syarat/');

    }

}