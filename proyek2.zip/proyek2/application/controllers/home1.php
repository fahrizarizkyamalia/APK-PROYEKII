<?php
 
class home1 extends CI_Controller
 
{

	 public function index()
    {
        $this->load->view('tutor/template');
    }



 public function Pageadmin(){
        if($this->session->userdata('level')==='admin'){
        	$this->load->view("isi/header.php");
         	$this->load->view("isi/menu2.php");
         	$this->load->view("isi/footer.php"); 
     		
      }else{
          echo "Access Denied";
      }
    }


     public function Pagetutor(){
        if($this->session->userdata('level')==='calon'){
          	$this->load->view("isi/header.php");
         	$this->load->view("isi/menu.php");
         	$this->load->view("isi/footer.php"); 
      }else{
          echo "Access Denied";
      }
    }


    public function tambahcalon2(){

    	$this->load->view('admin/form_biodata');


    }

    public function tambahberkas(){

    	$this->load->view('admin/v_upload');


    }
}