<?php
 
class tutor extends CI_Controller
 
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('auth_model');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->helper(array('form', 'url'));
        $this->load->model('m_pengumuman');
        $this->load->model('m_hasil');
        $this->load->model('m_prosedur');
        $this->load->model('m_syarat');
        $this->load->model('m_lowongan');

    }
 
    public function index()
    {
        $this->load->view('auth/login');
    }

   
   
 
    public function loginForm()
    {
    $username    = $this->input->post('username',TRUE);
    $password =  ($this->input->post('password',TRUE));
    $validate = $this->auth_model->validate($username,$password);
    if($validate->num_rows() > 0){
        $data  = $validate->row_array();
        $username = $data['username'];
        $level = $data['level'];
        $sesdata = array(
            'username'     => $username,
            'level'     => $level,
            'logged_in' => TRUE
        );
        $this->session->set_userdata($sesdata);
        // access login for admin
        if($level === 'admin'){
            redirect('home1/pageadmin');

        // access login for tutor
        }elseif($level === 'calon'){
            redirect('home1/Pagetutor');

    }else{
        echo $this->session->set_flashdata('msg','Username or Password is Wrong');
        redirect('tutor');
    }
     }
    }
    public function register()
    {
 
        $this->load->view('auth/register');
 
    }
 
    public function registerForm()
 
    {
 
        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');
        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('level', 'Level', 'required');
 
        if ($this->form_validation->run() == FALSE) {
 
            $errors = $this->form_validation->error_array();
            $this->session->set_flashdata('errors', $errors);
            $this->session->set_flashdata('input', $this->input->post());
            redirect('tutor/register');
 
        } else {
 
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $name = $this->input->post('nama_lengkap');
            $level = $this->input->post('level');
 
            $data = [
                'username' => $username,
                'password' => $password,
                'nama_lengkap' => $name,
                'level' => $level
            ];
 
            $insert = $this->auth_model->register("registrasi", $data);
 
            if($insert){
 
                $this->session->set_flashdata('success_login', 'Sukses, Anda berhasil register. Silahkan login sekarang.');
                redirect('tutor');
 
            }
        }
    }

    
 
    public function logout()
    {
        $this->session->sess_destroy();
        echo '<script>
            alert("Sukses! Anda berhasil logout."); 
            window.location.href="'.base_url('index.php/tutor').'";
            </script>';
    }


    public function pengumuman(){
         $data = array(

          
            'data_pengumuman' => $this->m_pengumuman->get_all(),

        );
        
        $this->load->view('tutor/data_pengumuman', $data);
      
    }


    public function pengumuman2(){
         $data = array(

          
            'data_pengumuman' => $this->m_pengumuman->get_all(),

        );
        
        $this->load->view('tutor/data_pengumuman2', $data);
      
    }


       public function hasil(){
         $data = array(

        
            'data_hasil' => $this->m_hasil->get_all(),

        );
        
        $this->load->view('tutor/data_hasil', $data);
      
    }

    public function prosedur(){
         $data = array(

        
            'data_prosedur' => $this->m_prosedur->get_all(),

        );
        
        $this->load->view('tutor/data_prosedur', $data);
      
    }
    public function syarat(){
         $data = array(

        
            'data_syarat' => $this->m_syarat->get_all(),

        );
        
        $this->load->view('tutor/data_syarat', $data);
      
    }

    public function lowongan(){
         $data = array(

        
            'data_lowongan' => $this->m_lowongan->get_all(),

        );
        
        $this->load->view('tutor/data_lowongan', $data);
      
    }
}
