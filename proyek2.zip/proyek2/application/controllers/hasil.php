<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hasil extends CI_Controller {

    public function __construct(){

        parent ::__construct();

        
        $this->load->model('m_hasil'); 
        

    }

    public function index()
    {
       $data ["data_hasil"] = $this->m_hasil->get_all();
           
        
        
        $this->load->view('hasil/data_hasil', $data);
      
        
    }

    public function tambah()
    {
       $this->load->model('calon_model');
        $data['calon'] = $this->calon_model->get_all();
        $this->load->view('hasil/hasil', $data);
    }
  
    public function simpan()
    {
            
            $nama_lengkap      =  $this->input->post("nama_lengkap");
            $hasil       =  $this->input->post("hasil");


            $data = array(
                
                'id_calon'    => $nama_lengkap,
                'hasil'  => $hasil,
                
            );
       $simpan =  $this->m_hasil->simpan($data);

        if ($simpan){

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }else{
        $this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }
        redirect('hasil/');

    }

      public function edit($id)
        {
            $this->load->model('calon_model');
            $this->load->model('m_hasil');

            $data['calon'] = $this->calon_model->get_all();

            $data['data_hasil'] = $this->m_hasil->get($id);

            $this->load->view('hasil/edit_hasil', $data);
        }


     public function update(){
            $this->load->model('m_hasil');
          
            $id = $this->input->post('id_hasil');
            $nama_lengkap = $this->input->post('nama_lengkap');
            $hasil = $this->input->post('hasil');

            $data = [
                'id_calon' => $nama_lengkap,
                'hasil' => $hasil,
            
            ];

        $save = $this->m_hasil->update($data, $id);

        if($save) {
            $this->session->set_flashdata('msg_success', 'Data telah diubah!');
        } else {
            $this->session->set_flashdata('msg_error', 'Data gagal disimpan, silakan isi ulang!');
        }
        redirect('hasil');
    }


    
    public function hapus($id_hasil)
    {
        $id['id_hasil'] = $this->uri->segment(3);

        $this->m_hasil->hapus($id);

        
        redirect('hasil/');

    }

}