<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class lowongan extends CI_Controller {

    public function __construct(){

        parent ::__construct();

        //load model
        $this->load->model('m_lowongan'); 
        

    }

    public function index()
    {
        $data = array(

            'title'     => 'lowongan',
            'data_lowongan' => $this->m_lowongan->get_all(),

        );
        
        $this->load->view('lowongan/data_lowongan', $data);
      
        
    }

    public function tambah()
    {
        $data = array(

            'title'     => 'Tambah Lowongan'
            
        );
        
        $this->load->view('lowongan/lowongan', $data);
    }
  
    public function simpan()
    {
        $data = array(

            'nama_lowongan'       => $this->input->post("nama_lowongan"),
             'status'       => $this->input->post("status"),
            

        );

        $simpan = $this->m_lowongan->simpan($data);

         if ($simpan){

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }else{
        $this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }
        redirect('lowongan/');

    }

      public function edit($id_lowongan)
    {
        $id_lowongan = $this->uri->segment(3);

        $data = array(

            'title'     => 'Edit Lowongan',
            'data_lowongan' => $this->m_lowongan->edit($id_lowongan)

        );

        $this->load->view('lowongan/edit_lowongan', $data);
    }


    public function update()
    {
        $id['id_lowongan'] = $this->input->post("id_lowongan");
        $data = array(

            'nama_lowongan' => $this->input->post("nama_lowongan"),
            'status' => $this->input->post("status"),


        );

        $this->m_lowongan->update($data, $id);

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil diupdate didatabase.
                                                </div>');

      
        redirect('lowongan/');

    }

    public function hapus($id_lowongan)
    {
        $id['id_lowongan'] = $this->uri->segment(3);

        $this->m_lowongan->hapus($id);

       
        redirect('lowongan/');

    }

}