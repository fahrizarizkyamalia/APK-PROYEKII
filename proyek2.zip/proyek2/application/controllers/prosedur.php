<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class prosedur extends CI_Controller {

    public function __construct(){

        parent ::__construct();

        //load model
        $this->load->model('m_prosedur'); 
        

    }

    public function index()
    {
        $data = array(

            'title'     => 'Prosedur Pendaftaran',
            'data_prosedur' => $this->m_prosedur->get_all(),

        );
        
        $this->load->view('prosedur/data_prosedur', $data);
      
        
    }

    public function tambah()
    {
        $data = array(

            'title'     => 'Tambah Prosedur'
            
        );
        
        $this->load->view('prosedur/prosedur', $data);
    }
  
    public function simpan()
    {
        $data = array(

            'isi_prosedur'       => $this->input->post("isi_prosedur"),
            

        );

        $simpan = $this->m_prosedur->simpan($data);

       if ($simpan){

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }else{
        $this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }

        
        redirect('prosedur/');

    }

      public function edit($id_prosedur)
    {
        $id_prosedur = $this->uri->segment(3);

        $data = array(

            'title'     => 'Edit Prosedur',
            'data_prosedur' => $this->m_prosedur->edit($id_prosedur)

        );

        $this->load->view('prosedur/edit_prosedur', $data);
    }


    public function update()
    {
        $id['id_prosedur'] = $this->input->post("id_prosedur");
        $data = array(

            'isi_prosedur' => $this->input->post("isi_prosedur"),


        );

        $this->m_prosedur->update($data, $id);

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil diupdate didatabase.
                                                </div>');

        redirect('prosedur/');

    }

    public function hapus($id_prosedur)
    {
        $id['id_prosedur'] = $this->uri->segment(3);

        $this->m_prosedur->hapus($id);

        //redirect
        redirect('prosedur/');

    }

}