<?php
 
class user extends CI_Controller
 
{

	 public function __construct()
    {

        parent ::__construct();


    	$this->load->model('user_model');
    }

     public function index()
    {
        $data = array(

            'data_user' => $this->user_model->get_all(),

        );
        $this->load->view('user/data_user', $data);
    }

    public function tambah(){

    	$data = array(

            'title'     => 'Tambah Data User'

        );

        $this->load->view('user/tambah_user', $data);
    }


     public function simpan(){

            $username      =  $this->input->post("username");
            $password      =  $this->input->post("password");
            $nama_lengkap =  $this->input->post("nama_lengkap");
            $level        = $this->input->post("jenis_level");
           




            $data = array(
                'username'             => $username,
                'password'             => $password,
                'nama_lengkap'      => $nama_lengkap,
                'level'             => $level,
                
            );

        

        $this->user_model->simpan($data, 'registrasi');

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil disimpan didatabase.
                                                </div>');

        //redirect
        redirect('user');
    }

     public function edit($id_registrasi)
    {
        $id_registrasi = $this->uri->segment(3);

        $data = array(

            'title'     => 'Edit Data user',
            'data_user' => $this->user_model->edit($id_registrasi)

        );

        $this->load->view('user/edit_user', $data);
    }


    public function update()
    {
        $id['id_registrasi'] = $this->input->post("id_registrasi");
        $data = array(

            'username'               =>  $this->input->post("username"),
            'password'     =>  $this->input->post("password"),
            'nama_lengkap'  =>  $this->input->post("nama_lengkap"),
            'level'        => $this->input->post("level"),


        );

        $this->user_model->update($data, $id);

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil diupdate didatabase.
                                                </div>');

        
        redirect('user/');

    }

    public function hapus($id_registrasi)
    {
        $id['id_registrasi'] = $this->uri->segment(3);

        $this->user_model->hapus($id);

        
        redirect('user/');

    }

    

}


