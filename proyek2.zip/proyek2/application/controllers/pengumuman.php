<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pengumuman extends CI_Controller {

    public function __construct(){

        parent ::__construct();

        //load model
        $this->load->model('m_pengumuman'); 
        

    }

    public function index()
    {
        $data = array(

            'title'     => 'Pengumuman',
            'data_pengumuman' => $this->m_pengumuman->get_all(),

        );
        
        $this->load->view('pengumuman/data_pengumuman', $data);
      
        
    }

    public function tambah()
    {
        $data = array(

            'title'     => 'Tambah Pengumuman'
            
        );
        
        $this->load->view('pengumuman/tambah_pengumuman', $data);
    }
  
    public function simpan()
    {
        $data = array(

            'isi_pengumuman'       => $this->input->post("isi_pengumuman"),
            

        );

        $simpan = $this->m_pengumuman->simpan($data);

         if ($simpan){

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }else{
        $this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }
        redirect('pengumuman/');

    }

      public function edit($id_pengumuman)
    {
        $id_pengumuman = $this->uri->segment(3);

        $data = array(

            'title'     => 'Edit Data Barang',
            'data_pengumuman' => $this->m_pengumuman->edit($id_pengumuman)

        );

        $this->load->view('pengumuman/edit_pengumuman', $data);
    }


    public function update()
    {
        $id['id_pengumuman'] = $this->input->post("id_pengumuman");
        $data = array(

            'isi_pengumuman' => $this->input->post("isi_pengumuman"),


        );

        $this->m_pengumuman->update($data, $id);

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil diupdate didatabase.
                                                </div>');

        //redirect
        redirect('pengumuman/');

    }

    public function hapus($id_pengumuman)
    {
        $id['id_pengumuman'] = $this->uri->segment(3);

        $this->m_pengumuman->hapus($id);

        //redirect
        redirect('pengumuman/');

    }

}