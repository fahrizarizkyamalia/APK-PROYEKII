<?php
 
class biodata extends CI_Controller
 
{

	 public function __construct()
    {

        parent ::__construct();


    	$this->load->model('calon_model');
    }

     public function index()
    {
       

           $data ["data_calon"] = $this->calon_model->get_all();
            $this->load->view('admin/data_calon', $data);
    }

    public function tambah(){

    	$this->load->model('m_lowongan');
        $data['lowongan'] = $this->m_lowongan->get_all();
        $this->load->view('tutor/form_biodata', $data);
    }


     public function simpan(){

            $NIK       =  $this->input->post("NIK");
            $nama_lengkap      =  $this->input->post("nama_lengkap");
            $nama_panggilann  =  $this->input->post("nama_panggilann");
            $jenis_kelamin         = $this->input->post("jenis_kelamin");
            $tempat_lahir        =  $this->input->post("tempat_lahir");
            $tgl_lahir      =  $this->input->post("tgl_lahir");
            $agama     =  $this->input->post("agama");
            $alamat      =  $this->input->post("alamat");
            $kode_pos    =  $this->input->post("kode_pos");
            $bhs_sehari    =  $this->input->post("bhs_sehari");
            $golongan_darah     =  $this->input->post("golongan_darah");
            $pend_terakhir  =  $this->input->post("pend_terakhir");
            $no_hp     =  $this->input->post("no_hp");
            $lowongan    =  $this->input->post("lowongan");





            $data = array(
                'NIK'             => $NIK,
                'nama_lengkap'    => $nama_lengkap,
                'nama_panggilann'  => $nama_panggilann,
                'jenis_kelamin'   => $jenis_kelamin,
                'tempat_lahir'    => $tempat_lahir,
                'tgl_lahir'       => $tgl_lahir,
                'agama'           => $agama,
                'alamat'          => $alamat,
                'kode_pos'        => $kode_pos,
                'bhs_sehari'      => $bhs_sehari,
                'golongan_darah'  => $golongan_darah,
                'pend_terakhir'   => $pend_terakhir,
                'no_hp'           => $no_hp,
                'id_lowongan'     => $lowongan,
            );

        

        $simpan = $this->calon_model->simpan($data, 'calon');

        if ($simpan){

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }else{
        $this->session->set_flashdata('notif', '<div class="alert alert-danger alert-dismissible"> Success! data berhasil disimpan.
                                                </div>');
         }

   
        redirect('biodata/tambah');
    }

     public function edit($id_calon)
    {
        $id_pengumuman = $this->uri->segment(3);

        $data = array(

            'title'     => 'Edit Data Barang',
            'data_calon' => $this->calon_model->edit($id_calon)

        );

        $this->load->view('tutor/edit_calon', $data);
    }


    public function update()
    {
        $id['id_calon'] = $this->input->post("id_calon");
        $data = array(

            'NIK'               =>  $this->input->post("NIK"),
            'nama_lengkap'     =>  $this->input->post("nama_lengkap"),
            'nama_panggilann'  =>  $this->input->post("nama_panggilann"),
            'jenis_kelamin'        => $this->input->post("jenis_kelamin"),
            'tempat_lahir'        =>  $this->input->post("tempat_lahir"),
            'tgl_lahir'      =>  $this->input->post("tgl_lahir"),
            'agama'           =>  $this->input->post("alamat"),
            'alamat'    =>  $this->input->post("tgl_alamat"),
            'kode_pos'  =>  $this->input->post("kode_pos"),
            'bhs_sehari'   =>  $this->input->post("bhs_sehari"),
            'golongan_darah'     =>  $this->input->post("golongan_darah"),
            'pend_terakhir' =>  $this->input->post("pend_terakhir"),
            'no_hp'     =>  $this->input->post("no_hp"),


        );

        $this->calon_model->update($data, $id);

        $this->session->set_flashdata('notif', '<div class="alert alert-success alert-dismissible"> Success! data berhasil diupdate didatabase.
                                                </div>');

        
        redirect('biodata/');

    }

    public function hapus($id_calon)
    {
        $id['id_calon'] = $this->uri->segment(3);

        $this->calon_model->hapus($id);

        //redirect
        redirect('biodata/');

    }

    public function pelamar(){

          $data ["data_calon"] = $this->calon_model->get_all();
            $this->load->view('admin/data_calon', $data);

    }

    

}


